print "this is f3"

def fun():
	return "this is fun in f3"
print "some statements to this file"
print fun()
print "some other statements to this file"
print "end of f3"