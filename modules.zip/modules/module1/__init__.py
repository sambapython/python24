print "this is init"
'''
import file1
import file2
'''
import file1
import file2