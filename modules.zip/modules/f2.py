'''
import f1
print fun()
'''

'''
import f1
print f1.fun()

'''
'''
import f1
print f1.fun()
'''
'''
import f3
print f3.fun()
'''

import f4
print f4.fun()