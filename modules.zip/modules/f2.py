'''
import f1
print fun()
'''

'''
import f1
print f1.fun()

'''
'''
import f1
print f1.fun()
'''
'''
import f3
print f3.fun()
'''
'''

import f4
print f4.fun()
'''
'''
import module1
'''
'''
import f15
'''
'''
import module1
import module1
'''
'''
from module1 import file1,file2
print file1.fun()
print file2.fun()
'''
'''
import module1
print module1.file1.fun()
'''
'''
import module1
print module1.file1.fun()
print module1.file2.fun()
'''
'''
from module1 import file1
'''
'''
import module1
'''
'''
import sqlite3
print sqlite3.__file__
import module1
import sys
print sys.path
'''
'''
import module1
import sys
print sys.path
'''
import sys
sys.path.append('/home/tcloudost')
import module1
